import os
import re
import xlwt
import decimal
import os


path=input() #输入文件
pathname=os.path.basename(path)
files = os.listdir(path)  # 得到文件夹下所有txt
i = 0  # 定义变量
f = xlwt.Workbook('encoding = utf-8')  # 创建一个workbook并设置编码
for file in files:
    position = path + '\\' + file  # 构造绝对路径
    pname=os.path.basename(position)
    f1 = open(position, "r", encoding='utf-8')  # 打开并读取文件信息
    data = f1.read()
    parrern = "[0-9]+\.+[0-9]+"  # 用正则匹配所需要的信息
    str2 = re.findall(parrern, data)  # 查找所有符合条件的信息

    # 平均每一层的所花费的时间
    str3 = 0
    for j in str2[:len(str2) - 1]:
        str3 += decimal.Decimal(j)
    result1 = str3 / len(str2)

    sheet1 = f.add_sheet('{}'.format(pname), cell_overwrite_ok=True)  # 创建sheet工作表
    sheet1.write(0, 0, '每层运行时间')
    sheet1.write(0,1,'总运行时间')
    sheet1.write(0, 2, '平均每层所花费的时间:')
    sheet1.col(0).width=6000
    sheet1.col(2).width=8000
    sheet1.col(1).width=3000
    for j in range(len(str2)-1):
        sheet1.write(j+1, 0, str2[j])
    sheet1.write(1,1,str2[len(str2)-1])
    sheet1.write(1,2,'{}'.format(result1))
    f.save(pathname+'.xls')
    f1.close()
    i += 1
